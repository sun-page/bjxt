import java.util.Scanner;
public class Fifth {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入一个两位整数：");
        int a = sc.nextInt();
        int x ,g,s;
        g = a%10;
        s = a/10;
        x = g*10+s;
        System.out.println(x);
    }
}