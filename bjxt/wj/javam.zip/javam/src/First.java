public class First {
    public static void main(String[] args) {
        int a = 3;
        int h = 3;
        float s = (float)a*h/2;
        System.out.println("定义三角形的高为3，底边为3");
        System.out.println("三角形面积为"+s);
    }
}