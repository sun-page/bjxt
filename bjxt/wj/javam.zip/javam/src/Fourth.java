public class Fourth {
    public static void main(String[] args) {
        char a ='A';
        int b = (int)a;
        System.out.println(b);
        char m = (char)(a+32);
        System.out.println(m);
    }
}