public class Second {
    public static void main(String[] args) {
        long num = 2022010120000L;
        String clas = "zb计科223";
        String name = "张三";
        int age = 19;
        char sex = '男';
        System.out.println("学号："+num + "\n" + "班级：" + clas + "\n" + "姓名：" + name + "\n" + "年龄：" + age + "\n" + "性别：" + sex );
    }
}