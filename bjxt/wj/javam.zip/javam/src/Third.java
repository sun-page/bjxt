import java.util.Scanner;
public class Third {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("请输入第一个数字：");
        double a = sc.nextDouble();
        System.out.print("请输入第二个数字：");
        double b = sc.nextDouble();
        System.out.println("交换前a="+a+"  b="+b);
        double d;
        d = a;
        a = b;
        b = d;
        System.out.print("交换后a="+a + "  b="+b);
    }
}